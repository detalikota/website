from setuptools import setup
setup (
    name='vsearch',
    version='1.0',
    description='My search tool',
    author='Magomed',
    author_email='detalikota@gmail.com',
    url='none',
    py_modules=['vsearch'],
)