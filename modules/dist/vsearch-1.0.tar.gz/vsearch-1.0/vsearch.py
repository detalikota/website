def search4letters(word,letters):
    return set(word).intersection(set(letters))